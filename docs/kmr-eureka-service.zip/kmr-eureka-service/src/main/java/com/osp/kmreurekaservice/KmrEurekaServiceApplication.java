package com.osp.kmreurekaservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class KmrEurekaServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(KmrEurekaServiceApplication.class, args);
	}

}
