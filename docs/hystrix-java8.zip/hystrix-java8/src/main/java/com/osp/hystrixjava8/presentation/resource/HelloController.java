package com.osp.hystrixjava8.presentation.resource;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class HelloController {

    RestTemplate restTemplate = new RestTemplate();
    @Value("${client.url}")
    String clientUrl;

    @GetMapping("/nohystrix")
    public String getMappingExample(){
        return restTemplate.getForObject(clientUrl,String.class);
    }

    @GetMapping("/hystrix")
    @HystrixCommand(groupKey = "fallback",commandKey="fallback", fallbackMethod = "hystrixFallBack")
    public String getMapping(){
        return restTemplate.getForObject(clientUrl,String.class);
    }

    public String hystrixFallBack(){
            return "Target Application is down";
    }
}
