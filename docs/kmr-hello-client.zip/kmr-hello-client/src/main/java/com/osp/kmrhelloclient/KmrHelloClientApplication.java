package com.osp.kmrhelloclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KmrHelloClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(KmrHelloClientApplication.class, args);
	}

}
