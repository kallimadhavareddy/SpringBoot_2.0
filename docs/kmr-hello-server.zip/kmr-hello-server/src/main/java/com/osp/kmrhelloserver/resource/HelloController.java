package com.osp.kmrhelloserver.resource;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
    @GetMapping("/hystrix")
    public String getMapping(){
        return "this kmr-jello-server-greetings";
    }
}
